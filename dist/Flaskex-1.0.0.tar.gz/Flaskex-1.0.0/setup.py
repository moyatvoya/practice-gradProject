from setuptools import find_packages, setup

setup(
    name='Flaskex',
    version='1.0.0',
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
    install_requires=[
        'flask',
		'WTForms',
		'SQLAlchemy',
		'bcrypt',
		'requests',
		'flask-heroku',
		'gunicorn',
    ],
    tests_require=['pytest'],
    entry_points={'console_scripts': ['flaskex=app:app']},
    package_data={'': ['*.js', '*.html', '*.css']}
)


